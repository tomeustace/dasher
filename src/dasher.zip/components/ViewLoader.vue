<template>
</template>
<script>

const d3 = require('d3');

/*eslint-disable */

/**
 * On mounted check if views exist.  If they do load them. 
 */
function mounted() {
  var data = ['box1','box2','box3'];
  var app = d3.select('#container').attr('class','container');
}

const vm = {
  data() {
    return {
      counter: 0,
    };
  },
  methods: { },
  beforeCreate() { },
  created() { },
  beforeMount() { },
  mounted() { },
  beforeUpdate() { },
  updated() { },
};
/*eslint-disable */
export default vm;
</script>

<style>
#start-container {
  margin-top: 20%;
  color: #616161;
  margin: 10% auto;
  width: 40%;

}
h3 {
  opacity: .9;
}
</style>
