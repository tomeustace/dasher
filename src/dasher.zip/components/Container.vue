<template>
  <div>
    <div v-if="views.length === 0">
      <md-card id="start-container">
          <md-card-content>
            <h3>Create a view and add some components to start.</h3>
          </md-card-content>
      </md-card>
    </div>
    <div id="container" v-if="views.length > 0">

      <md-dialog md-open-from="#custom" md-close-to="#custom" ref="addComponentDialog">
        <md-dialog-title v-model="activeView">{{activeView}} Choose Components</md-dialog-title>

        <md-dialog-content>
          <!-- <div v-for="option in components"> -->
          <div v-for="option in getComponents">
            <p href="#" @click="addWidget(activeView, option)">{{option}}</p>
            <!--<md-checkbox :true-value="option" :false-value="!option" :id="option" :name="option" v-model="selectedOptions">{{option}}</md-checkbox>-->
          </div>
        </md-dialog-content>

        <md-dialog-actions>
          <!--
          <md-button class="md-primary" v-model="selectedOptions" @click="closeDialog('addComponentDialog')">Cancel</md-button>
          <md-button class="md-primary" v-model="selectedOptions" @click="closeDialog('addComponentDialog')">Ok</md-button>
          -->
          <md-button class="md-primary" @click="closeDialog('addComponentDialog')">Cancel</md-button>
          <md-button class="md-primary" @click="closeDialog('addComponentDialog')">Ok</md-button>
        </md-dialog-actions>
      </md-dialog>

      <md-tabs>
        <md-tab v-for="(view, index) in views" v-bind:id="view.name" v-on:click="changeView('tom')" :index="index" v-bind:md-label="view.name">

          <component-shell v-for="(widget, index) in view.widgets" :index="index" :is="widget.name"></component-shell>

          <div id="bottom-bar">
            <md-button @click="openDialog(view.name, 'addComponentDialog')">
              <md-tooltip>Add Component</md-tooltip>
              <md-icon>add</md-icon>
            </md-button>
            <md-button @click="removeWidget(view.name)">
              <md-tooltip>Delete All Components</md-tooltip>
              <md-icon>delete</md-icon>
            </md-button>
          </div>
        </md-tab>
      </md-tabs>
    </div>
  </div>
</template>
<script>

import { mapState } from 'vuex';
import { getViewNames } from './../util/ViewLoader';
import ComponentShell from './ComponentShell';
import Widget1 from './../widgets/Widget1';
import Widget2 from './../widgets/Widget2';

/*eslint-disable */
function created() {
  console.log(vm.components);
}

var components = { ComponentShell, Widget1, Widget2, };

const vm = {
  data() {
    return { 
      selected: '',
      activeView: '',
      widgets: [],
      components: Object.keys(components),
    };
  },
  created: function created() {
    //On create load any pre configured views
    var viewNames = getViewNames();
    var loadedViews = localStorage.getItem('vd.views');
    loadedViews = JSON.parse(loadedViews);
    this.$store.dispatch('loadViews', loadedViews); ;
  },
  computed: {
    // map this.views to store.state.views
    ...mapState(['views','views.widgets']),
    //Adds available components to dialog for selection
    getComponents: function() {
      var widgets = [];
      this.components.forEach(function(item) {
        if(item.toLowerCase().charAt(0) === 'w') {
          widgets.push(item); 
        }
      });
      return widgets;
    },
  },
  methods: {
    changeView(activeView) {
      alert('changing view');
    },
    addWidget(activeView, name) {
      console.log('Container.addWidget');
      this.$store.dispatch('addWidgetToView', {name: activeView, widget: name});
    },
    openDialog(viewName, ref) {
      this.activeView = viewName;
      this.$refs[ref].open();
    },
    closeDialog(ref) {
      //console.log(this.selectedOptions);
      this.$refs[ref].close();
    },
  },
  components: components,
};

/*eslint-disable */
export default vm;
</script>

<style>

#container {
  background-color: #cccccc;
  display:flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: flex-start;
  align-content: flex-start;
  align-items: flex-start;
  width: 100%;
  height: 90%;
}
#add-component {
  max-width: 400px;
  display:flex;
  flex-direction: row;
  justify-content: flex-end;
  align-content: flex-end;
  align-items: flex-end;
}
#bottom-bar {
  background-color: white;
}
</style>
