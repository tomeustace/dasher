<template>
  <div :id="_uid" :cid="cid" class="component-shell">
    <md-toolbar class="md-dense">
      <md-button class="md-icon-button">
	<md-icon>menu</md-icon>
      </md-button>

      <h2 class="md-title" style="flex: 1">Name</h2>

      <md-button @click="removeComponent" class="md-icon-button">
	<md-icon>delete</md-icon>
      </md-button>
    </md-toolbar> 

    <md-card>
        <md-card-header>
          <slot name="name"></slot>
          <p>- cid: {{cid}}</p>
        </md-card-header>

        <md-card-content>
          <slot name="widget1"></slot>
	</md-card-content>
    </md-card>

  </div>
</template>
<script>

/*eslint-disable */

import { removeComponentFromView } from './../util/ViewLoader';

function created() {
  console.log('in created');
}

var widgetCount = 0;
/* crude way to increment number of times beforeMount is called */
function incrementWidgetCount() {
  widgetCount++;
}

const vm = {
  data() {
    return {
      counter: 0,
      widget: '',
      id: this._uid, 
      cid: '',
    };
  },
  methods: { 
    removeComponent: function(name) {
      console.log(this.$parent.$data.name);
      //TODO fix below parent references, find cleaner way
      this.$store.dispatch('removeWidgetFromView', {name: this.$parent.$parent.$el.id, cid: this.$data.cid, widget: this.$parent.$data.name});
    }
  },
  beforeCreate() { },
  created() { },
  beforeMount() {
  },
  mounted() { 
    let index = this.$parent.$parent.$el.getAttribute('index');
    let widgetIndex = this.$parent.$el.getAttribute('index');
    console.log('ComponentShell - beforeMount index ', index);
    let widget = this.$store.state.views[index].widgets[widgetIndex];
    if(!_.isUndefined(widget)) {
      console.log('ComponentShell - beforeMount ', widget.cid);
      this.$data.cid = widget.cid;
    } else {
      console.log('ComponentShell - beforeMount ERROR');
    }
  },
  beforeUpdate() { },
  updated() { },
};
/*eslint-disable */
export default vm;
</script>

<style>
.component-shell {
  flex-direction: row;
  min-width: 200px;
  max-width: 400px;
  min-height: 200px;
}
.md-card-header {
  display: flex;
}
</style>
